---
aliases: example page
tags: seedling, 
---

# Ipsum

Lorem ipsum dolor sit amet, consectetur __adipiscing__ elit. 

> Curabitur [[The Core]] sapien sed molestie. Aenean sed mollis mauris. Etiam mattis neque quis gravida scelerisque. Phasellus efficitur, leo vel blandit luctus, erat ipsum dictum lorem.

## Quisque dictum

Etiam mattis neque quis gravida scelerisque [@Grieser2018]:

```shell
msg="Hello World"
echo -n "$msg"
```

Donec porta, nibh et placerat bibendum, leo dolor ultrices neque, vel tristique metus mi congue massa. Morbi lobortis placerat tellus, vel fringilla nisi vulputate at. Nulla eu lacinia leo. Curabitur lobortis sed sem quis faucibus. Phasellus efficitur, leo vel blandit luctus, erat ipsum dictum lorem, sed molestie tortor risus ut nunc. Aliquam rhoncus justo eu interdum aliquet.